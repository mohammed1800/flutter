import 'package:flutter/material.dart';
import 'package:newapp/main.dart';

class Logoutscreen extends StatefulWidget {
  const Logoutscreen({super.key});

  @override
  State<Logoutscreen> createState() => _LogoutscreenState();
}

class _LogoutscreenState extends State<Logoutscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Welcome to my app'),
          backgroundColor: const Color.fromARGB(255, 218, 8, 8),
          centerTitle: true,
        ),
        body: Center(
          child: GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => MyHomePage()));
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.green,
                ),
                child: const Padding(
                  padding: EdgeInsets.all(15.0),
                  child: const Text('log in to the app'),
                ),
              )),
        ));
  }
}
